//
//  ItemsViewModel.swift
//  
//
//  Created by Louisa Gareiss on 2/13/24.
//

import SwiftUI

class ItemsViewModel: ObservableObject {
    @Published var items: [Item] {
        didSet {
            saveItems()
        }
    }

    init() {
        self.items = UserDefaults.standard.itemsArray()
    }

    func addItem(item: Item) {
        items.append(item)
    }

    func removeItem(at index: IndexSet) {
        items.remove(atOffsets: index)
    }

    private func saveItems() {
        UserDefaults.standard.setItemsArray(items)
    }
    func toggleFavorite(for item: Item) {
        if let index = items.firstIndex(where: { $0.id == item.id }) {
            items[index].isFavorite.toggle()
            saveItems()
        }
    }

}
