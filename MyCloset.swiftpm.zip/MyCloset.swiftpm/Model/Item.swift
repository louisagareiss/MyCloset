//
//  Item.swift
//  
//
//  Created by Louisa Gareiss on 2/13/24.
//

import SwiftUI

struct Item: Identifiable, Codable {
    var id = UUID()
    var itemname: String
    var brandname: String
    var notes: String
    var reflection: String
    var imageData: Data?
    var isFavorite: Bool
    
    func getImage() -> Image? {
        if let imageData = imageData, let uiImage = UIImage(data: imageData) {
            return Image(uiImage: uiImage)
        }
        return nil
    }
}

extension UserDefaults {
    func itemsArray() -> [Item] {
        if let data = data(forKey: "items") {
            let decoder = JSONDecoder()
            if let items = try? decoder.decode([Item].self, from: data) {
                return items
            }
        }
        return []
    }

    func setItemsArray(_ items: [Item]) {
        let encoder = JSONEncoder()
        if let data = try? encoder.encode(items) {
            set(data, forKey: "items")
        }
    }
}
