//
//  HomeView.swift
//  
//
//  Created by Louisa Gareiss on 2/13/24.
//

import SwiftUI

struct HomeView: View {
    @StateObject private var viewModel = ItemsViewModel()
    @State private var openTipsSheet = false
    @State private var openAddItemSheet = false
    @State private var selectedFilter = "All"
    let filters = ["All", "Favorites"]

    var filteredItems: [Item] {
        if selectedFilter == "All" {
            return viewModel.items
        } else {
            return viewModel.items.filter { $0.isFavorite }
        }
    }

    var body: some View {
        NavigationView {
            VStack {
                HStack {
                    Text("MyCloset")
                        .font(.largeTitle)
                        .bold()
                    Picker(selection: $selectedFilter, label: Text("Explore")) {
                        ForEach(filters, id: \.self) { theme in
                            Text(theme)
                                .font(.body)
                        }
                    }
                    .pickerStyle(DefaultPickerStyle())
                    .tint(Color("backgroundColor"))
                    .bold()
                    Spacer()
                    Button(action: { openTipsSheet.toggle() }) {
                        ZStack {
                            Circle()
                                .frame(width: 40, height: 40)
                                .foregroundStyle(Color("backgroundColor"))
                            Image(systemName: "lightbulb.fill")
                                .foregroundStyle(.yellow)
                                .font(.title3)
                                .fontWeight(.bold)
                        }
                    }

                    Button(action: { openAddItemSheet.toggle() }) {
                        ZStack {
                            Circle()
                                .frame(width: 40, height: 40)
                                .foregroundStyle(Color("backgroundColor"))
                            Image(systemName: "plus")
                                .foregroundStyle(.primary)
                                .font(.title3)
                                .fontWeight(.bold)
                        }
                    }
                }
                .padding()

                if filteredItems.isEmpty {
                    Text(selectedFilter == "All" ? "Add your first item to your Closet by tapping on the + Button" : "You haven't favorited any items yet.")
                        .font(.title)
                        .foregroundColor(.gray)
                        .padding(.top, 100)
                } else {
                    List {
                        ForEach(filteredItems) { item in
                            NavigationLink(destination: ItemDetailView(item: item, viewModel: viewModel)) {
                                item.getImage()?
                                    .resizable()
                                    .frame(width: 200, height: 200)
                                    .cornerRadius(20)
                                Text(item.itemname)
                                    .font(.largeTitle)
                                    .bold()
                            }
                        }
                        .onDelete { indexSet in
                            viewModel.removeItem(at: indexSet)
                        }
                    }
                }
                Spacer()
            }
            .sheet(isPresented: $openTipsSheet) {
                TipsView()
            }
            .sheet(isPresented: $openAddItemSheet) {
                AddItemView(viewModel: viewModel)
            }
        }
        .navigationViewStyle(.stack)
        .navigationBarBackButtonHidden(true)
    }
}
