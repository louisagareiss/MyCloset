//
//  CustomButton.swift
//  
//
//  Created by Louisa Gareiss on 2/13/24.
//

import SwiftUI

struct CustomButton: View {
    var action: () -> Void
    var label: String
    var body: some View {
        Button(action: action, label: {
            ZStack {
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .fill(Color("backgroundColor"))
                    .frame(height: 55)
                    .frame(width: 500)
                Text(label)
                    .font(.body)
                    .bold()
                    .foregroundStyle(Color(.accent))
            }.padding()
        })
    }
}
