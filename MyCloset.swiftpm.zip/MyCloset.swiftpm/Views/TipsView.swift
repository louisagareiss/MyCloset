//
//  TipsView.swift
//
//
//  Created by Louisa Gareiss on 2/13/24.
//

import SwiftUI

struct TipsView: View {
    var body: some View {
        ScrollView {
            VStack(alignment: .leading) {
                Text("If you have clothes that you don't wear anymore, don't throw them away instead you can: ")
                    .bold()
                    .font(.title3)
                    .padding(.bottom, 45)
                
                Text("Donate your clothes to charity")
                    .bold()
                
                Text("You can donate your clothes if they are in good condition. Search for your local organization online.")
                    .padding(.bottom, 25)
                    .foregroundStyle(.gray)
                
                Text("Recycle your clothes")
                    .bold()
                
                Text("If your clothes are made from natural material you can bring them to your local recycling facility and they can get recycled.")
                    .padding(.bottom, 25)
                    .foregroundStyle(.gray)
                
                Text("Ask family and friends if they need them")
                    .bold()
                
                Text("Ask your family and friends (with younger children) if they want some of your clothes.")
                    .padding(.bottom, 25)
                    .foregroundStyle(.gray)
                
                Text("Upcycle your clothes")
                    .bold()
                
                Text("Upcycling is a very creative and fun way to make use of your clothes, especially if they don't fit you anymore.")
                    .padding(.bottom, 25)
                    .foregroundStyle(.gray)
                
                Text("Sell your clothes")
                    .bold()
                
                Text("You can sell your clothes online or organize garage sale at your local community.")
                    .padding(.bottom)
                    .foregroundStyle(.gray)
                
                HStack {
                    VStack {
                        Text("Did you know that...")
                            .font(.headline)
                            .padding(.top)
                       
                        Text("The fashion industry is responsible for approximately 10% of global carbon emissions, making it one of the largest contributors to environmental pollution.")
                            .multilineTextAlignment(.center)
                            .padding()
                    }
                    .frame(width: 300)
                    .background(Color.blue.opacity(0.2))
                    .cornerRadius(10)
                    .padding()
                    
                    VStack {
                        Text("Did you know that...")
                            .font(.headline)
                            .padding(.top)
                        
                        Text("Producing one cotton T-shirt requires an average of 2,700 liters of water, contributing significantly to water scarcity and environmental strain.")
                            .multilineTextAlignment(.center)
                            .padding()
                    }
                    .frame(width: 300)
                    .background(Color.green.opacity(0.2))
                    .cornerRadius(10)
                    .padding()
                    
                }
                HStack {
                    VStack {
                        Text("Did you know that...")
                            .font(.headline)
                            .padding(.top)
                        
                        Text("Polyester, commonly used in clothing, is derived from petroleum and takes hundreds of years to decompose, contributing to plastic pollution in oceans and landfills.")
                            .multilineTextAlignment(.center)
                            .padding()
                    }
                    .frame(width: 300)
                    .background(Color.orange.opacity(0.2))
                    .cornerRadius(10)
                    .padding()
                    
                    VStack {
                        Text("Did you know that...")
                            .font(.headline)
                            .padding(.top)
                         
                        Text("The fashion industry is the second-largest consumer of water worldwide, with an estimated 20% of global wastewater coming from textile dyeing and treatment.")
                            .multilineTextAlignment(.center)
                            .padding()
                    }
                    .frame(width: 300)
                    .background(Color.purple.opacity(0.2))
                    .cornerRadius(10)
                    .padding()
                }
                Spacer()
            }
            .padding()
        }
    }
}

#Preview {
    TipsView()
}
