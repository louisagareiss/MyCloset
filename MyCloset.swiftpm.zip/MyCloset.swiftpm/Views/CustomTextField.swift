//
//  CustomTextField.swift
//
//
//  Created by Louisa Gareiss on 2/13/24.
//

import SwiftUI

struct CustomTextField: View {
    var placeHolder: String
    @Binding var text: String
    var body: some View {
        VStack {
            ZStack {
                TextField(placeHolder, text: $text)
                    .font(.body)
                    .padding()
                    .frame(width: 500)
                    .background(Color(.systemGray5))
                    .cornerRadius(15.0)
                    .padding(.horizontal)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
            }.frame(maxWidth: .infinity)
        }
    }
}

#Preview {
    CustomTextField(placeHolder: "some text", text: .constant(""))
}
