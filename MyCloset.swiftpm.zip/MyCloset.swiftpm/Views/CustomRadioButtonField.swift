//
//  File.swift
//  
//
//  Created by Louisa Gareiss on 2/15/24.
//

import Foundation
import SwiftUI

struct CustomRadioButtonField: View {
    let id: String
    let label: String
    let isSelected: Bool
    let callback: (String)->()
    var body: some View {
        Button(action:{
            self.callback(self.id)
        }) {
            HStack(alignment: .center, spacing: 20) {
                Image(systemName: self.isSelected ? "largecircle.fill.circle" : "circle")
                    .frame(width: 5, height: 20)
                Text(label)
                    .font(.body)
            }.foregroundColor(Color("backgroundColor"))
        }
        .foregroundColor(Color.white)
    }
}
    
struct CustomRadioButtonView_Previews: PreviewProvider {
    static var previews: some View {
        CustomRadioButtonField(id: "", label: "", isSelected: false) { _ in
        }
    }
}
