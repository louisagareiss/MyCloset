//
//  OnboardingView.swift
//
//
//  Created by Louisa Gareiss on 2/13/24.
//

import SwiftUI

struct OnboardingView: View {
    var body: some View {
        NavigationView {
            VStack {
                HStack {
                    Text("Welcome to My Closet")
                        .font(.largeTitle)
                        .bold()
                    Spacer()
                    NavigationLink {
                        HomeView()
                    } label: {
                        Image(systemName: "xmark")
                            .foregroundStyle(Color("backgroundColor"))
                            .font(.title3)
                            .bold()
                    }
                }.padding(.bottom, 90)
                    .padding(.horizontal)
             
                VStack(alignment: .leading) {
                    Text("- Keep track of your clothes and easily declutter your closet.")
                    Text("It's simple just start right here.")
                        .foregroundStyle(.gray)
                        .padding(.bottom, 45)
                    
         
                    Text("- Reflect on what you can do with clothes that you don't wear anymore.")
                    
                    Text("Learn with you can do with your clothes instead of throwing them away.")
                        .foregroundStyle(.gray)
                        .padding(.bottom, 45)
                        
                    Text("- Help protect the enviroment by not throwing your clothes away and reduce your carbon footprint.")
                    Text("A lot of fossil fuels are burned to produce clothes and transport them to you.")
                        .foregroundStyle(.gray)
                        .padding(.bottom, 45)
                }.font(.title3)
                    .bold()
                    
                Image("tshirt")
                    .padding(.vertical, 45)
                    
                NavigationLink {
                    HomeView()
                } label: {
                    ZStack {
                        RoundedRectangle(cornerRadius: 20, style: .continuous)
                            .fill(Color("backgroundColor"))
                            .frame(height: 55)
                            .frame(width: 500)
                        Text("Let's go")
                            .font(.body)
                            .bold()
                            .foregroundStyle(Color(.accent))
                    }.padding()
                }
                Spacer()
            }.padding()
        }.navigationViewStyle(.stack)
    }
}
