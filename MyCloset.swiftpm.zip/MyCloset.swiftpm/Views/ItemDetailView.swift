//
//  ItemDetailView.swift
//  
//
//  Created by Louisa Gareiss on 2/14/24.
//

import SwiftUI

struct ItemDetailView: View {
    let item: Item
    @ObservedObject var viewModel: ItemsViewModel

    var body: some View {
        NavigationView {
            VStack {
                HStack {
                    NavigationLink {
                        HomeView()
                    } label: {
                        Image(systemName: "chevron.backward")
                            .foregroundStyle(Color("backgroundColor"))
                            .bold()
                            .padding()
                        Spacer()
                    }
                }
                item.getImage()?
                    .resizable()
                    .frame(width: 400, height: 400)
                    .cornerRadius(20)
                    .padding(.vertical, 45)
                HStack {
                    Text(item.itemname)
                        .font(.largeTitle)
                        .bold()
                    
                    Button(action: {
                        viewModel.toggleFavorite(for: item)
                    }) {
                        ZStack {
                            Circle()
                                .shadow(color: Color.black.opacity(0.3), radius: 36, x: 0, y: 18)
                                    
                                .frame(width: 40, height: 40)
                            Image(systemName: item.isFavorite ? "heart.fill" : "heart")
                                .foregroundColor(item.isFavorite ? .red : .gray)
                                
                        }
                    }.padding(.leading)
                    
                }
                Text(item.brandname)
                    .font(.title3)
                    .foregroundStyle(.gray)
                    .padding(.bottom, 45)
        
                Text("Notes")
                    .foregroundStyle(Color("backgroundColor"))
                    .padding(.bottom)
                    .font(.title3)
                    .bold()
            
                VStack(alignment: .leading) {
                   
                    Text(item.notes)
                        .padding(.bottom)
                    
                    Text(item.reflection)
                    
                }
                Spacer()
            }
        }.navigationViewStyle(.stack)
            .navigationBarBackButtonHidden(true)
    }
}
