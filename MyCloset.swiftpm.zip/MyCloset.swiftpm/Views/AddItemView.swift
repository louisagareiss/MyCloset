//
//  AddItemView.swift
//  
//
//  Created by Louisa Gareiss on 2/13/24.
//

import SwiftUI

struct AddItemView: View {
    @Environment(\.presentationMode) var presentationMode
    @ObservedObject var viewModel: ItemsViewModel
    @State private var itemname = ""
    @State private var brandname = ""
    @State private var notes = ""
    @State private var reflection = ""
    @State private var image: UIImage? = nil
    @State private var showImagePicker = false
    @State private var showAlert = false
    @State private var alertMessage = ""
    var body: some View {
        ScrollView {
            VStack {
                if let image = image {
                    Image(uiImage: image)
                        .resizable()
                        .frame(width: 300, height: 300)
                        .clipShape(RoundedRectangle(cornerRadius: 25.0))
                        .padding()
                        .onTapGesture {
                            showImagePicker.toggle()
                        }
                } else {
                    Button(action: {
                        showImagePicker.toggle()
                    }) {
                        ZStack {
                            RoundedRectangle(cornerRadius: 25.0)
                                .frame(width: 300, height: 300)
                                .foregroundColor(Color(.systemGray5))
                                .cornerRadius(25)
                            Image(systemName: "camera")
                                .font(.largeTitle)
                                .foregroundStyle(Color("backgroundColor"))
                        }
                    }
                    .padding()
                }
                CustomTextField(placeHolder: "Name", text: $itemname)
                    .padding(.top, 25)
                Text("Give the Item a Name or a brief description eg. black SSC23 hoodie")
                    .font(.footnote)
                    .foregroundStyle(.gray)
                    .padding(.bottom, 25)
                CustomTextField(placeHolder: "Brand (optional)", text: $brandname)
                Text("Who made or designed this Item? eg. Apple")
                    .font(.footnote)
                    .foregroundStyle(.gray)
                    .padding(.bottom, 25)
                CustomTextField(placeHolder: "Notes", text: $notes)
                Text("eg. Why do I have this Item in my closet? or What do I love about this Item?")
                    .font(.footnote)
                    .foregroundStyle(.gray)
                    .padding(.bottom, 25)
                
                RadioButtonGroups(reflection: $reflection)
                
                CustomButton(action: {
                    
                    if image == nil {
                        showAlert = true
                        alertMessage = "Please provide a picture."
                    } else if itemname.isEmpty {
                        showAlert = true
                        alertMessage = "Give the Item a Name or a brief description."
                    } else if notes.isEmpty {
                        showAlert = true
                        alertMessage = "Please provide some notes. Why do you have this Item in your closet?"
                    } else {
                        let newItem = Item(itemname: itemname, brandname: brandname, notes: notes, reflection: reflection, imageData: image?.jpegData(compressionQuality: 0.8), isFavorite: false)
                        viewModel.addItem(item: newItem)
                        itemname = ""
                        image = nil
                        presentationMode.wrappedValue.dismiss()
                    }
                }, label: "Add Item")
            }
            .padding(.top)
            .sheet(isPresented: $showImagePicker) {
                CameraView(image: $image)
            }
            .alert(isPresented: $showAlert) {
                Alert(title: Text("My Closet"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
            }
        }
    }
}

struct RadioButtonGroups: View {
    @Binding var reflection: String
    @State var selectedId: String = ""
    
    enum Selection: String {
        case yes = "Yes"
        case no = "No"
    }
    var body: some View {
        VStack {
            Text("Do you wear this Item regularly?")
            HStack(spacing: 40) {
                radioNo
                radioYes
            }
            if selectedId == Selection.no.rawValue {
                CustomTextField(placeHolder: "Think of what you can do with it...", text: $reflection)
            }
        }
    }
    
    var radioNo: some View {
        CustomRadioButtonField(
            id: Selection.yes.rawValue,
            label: Selection.yes.rawValue,
            isSelected: selectedId == Selection.yes.rawValue ? true : false,
            callback: radioGroupCallback
        )
    }
    
    var radioYes: some View {
        CustomRadioButtonField(
            id: Selection.no.rawValue,
            label: Selection.no.rawValue,
            isSelected: selectedId == Selection.no.rawValue ? true : false,
            callback: radioGroupCallback
        )
    }
    
    func radioGroupCallback(id: String) {
        selectedId = id
    }
}
